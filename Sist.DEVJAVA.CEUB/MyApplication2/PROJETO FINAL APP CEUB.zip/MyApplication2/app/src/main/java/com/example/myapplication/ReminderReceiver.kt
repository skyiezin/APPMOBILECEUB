package com.example.myapplication

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val builder = NotificationCompat.Builder(context, "monthly_reminder")
            .setSmallIcon(R.drawable.ic_launcher_foreground) // ou outro ícone do seu projeto
            .setContentTitle("Lembrete financeiro")
            .setContentText("Já cadastrou seus dados financeiros do mês?")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)

        with(NotificationManagerCompat.from(context)) {
            notify(1001, builder.build())
        }
    }
}

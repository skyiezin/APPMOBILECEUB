package com.example.myapplication

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import java.time.YearMonth

private val Context.dataStore by preferencesDataStore(name = "finance_prefs")

class FinancePreferences(private val context: Context) {

    private fun keyFor(user: String, prefix: String, month: String): Preferences.Key<String> {
        return stringPreferencesKey("${user}_${prefix}_$month")
    }

    fun saveFinanceData(
        username: String,  // Adicione isso
        month: String,
        salary: String,
        fixed: String,
        variable: String,
        emergency: String,
        goal: String
    ) = runBlocking {
        context.dataStore.edit { prefs ->
            prefs[stringPreferencesKey("${username}_salary_$month")] = salary
            prefs[stringPreferencesKey("${username}_fixed_$month")] = fixed
            prefs[stringPreferencesKey("${username}_variable_$month")] = variable
            prefs[stringPreferencesKey("${username}_emergency_$month")] = emergency
            prefs[stringPreferencesKey("${username}_goal_$month")] = goal
        }
    }

    fun getFinanceData(username: String, month: String): Map<String, String> = runBlocking {
        val prefs = context.dataStore.data.first()
        return@runBlocking mapOf(
            "salary" to (prefs[stringPreferencesKey("${username}_salary_$month")] ?: ""),
            "fixed" to (prefs[stringPreferencesKey("${username}_fixed_$month")] ?: ""),
            "variable" to (prefs[stringPreferencesKey("${username}_variable_$month")] ?: ""),
            "emergency" to (prefs[stringPreferencesKey("${username}_emergency_$month")] ?: ""),
            "goal" to (prefs[stringPreferencesKey("${username}_goal_$month")] ?: "")
        )
    }


    fun getAllMonths(username: String): List<String> = runBlocking {
        val prefs = context.dataStore.data.first()
        val months = prefs.asMap().keys.mapNotNull { key ->
            val rawKey = key.name
            val prefix = "${username}_salary_"
            if (rawKey.startsWith(prefix)) {
                rawKey.removePrefix(prefix)
            } else null
        }
        months.distinct()
    }


    fun getCurrentMonth(): String {
        val now = YearMonth.now()
        return "${now.monthValue.toString().padStart(2, '0')}-${now.year}"
    }
    fun deleteFinanceData(user: String, month: String) = runBlocking {
        context.dataStore.edit { prefs ->
            prefs.remove(stringPreferencesKey("${user}_salary_$month"))
            prefs.remove(stringPreferencesKey("${user}_fixed_$month"))
            prefs.remove(stringPreferencesKey("${user}_variable_$month"))
            prefs.remove(stringPreferencesKey("${user}_emergency_$month"))
            prefs.remove(stringPreferencesKey("${user}_goal_$month"))
        }
    }
    fun getAllFinanceData(username: String): Map<String, Map<String, Double>> = runBlocking {
        val prefs = context.dataStore.data.first()
        val data = mutableMapOf<String, MutableMap<String, Double>>()

        prefs.asMap().forEach { (key, value) ->
            val rawKey = key.name
            if (rawKey.startsWith("${username}_")) {
                val parts = rawKey.removePrefix("${username}_").split("_")
                if (parts.size == 2) {
                    val campo = parts[0]
                    val mesAno = parts[1]
                    val valorDouble = (value as? String)?.toDoubleOrNull() ?: return@forEach

                    val existente = data.getOrPut(mesAno) { mutableMapOf() }
                    existente[campo] = valorDouble
                }
            }
        }

        return@runBlocking data
    }

    }




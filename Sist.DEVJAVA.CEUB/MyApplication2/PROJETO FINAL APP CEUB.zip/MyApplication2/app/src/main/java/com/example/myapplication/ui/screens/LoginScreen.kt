package com.example.myapplication.ui.screens

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.navigation.NavController
import com.example.myapplication.UserPreferences
import com.example.myapplication.ThemeViewModel

@Composable
fun LoginScreen(
    navController: NavController,
    themeViewModel: ThemeViewModel
) {
    val context = LocalContext.current
    val userPrefs = remember { UserPreferences(context) }

    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    val isDarkTheme by themeViewModel.isDarkTheme.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Bem-vindo ao Planejador Financeiro",
            style = MaterialTheme.typography.headlineSmall
        )

        OutlinedTextField(
            value = username,
            onValueChange = { username = it },
            label = { Text("Usuário") },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Senha") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Button(
                onClick = {
                    val user = userPrefs.getUser(username)
                    when {
                        user["name"].isNullOrBlank() -> {
                            Toast.makeText(context, "Usuário não encontrado!", Toast.LENGTH_SHORT).show()
                        }
                        password != user["password"] -> {
                            Toast.makeText(context, "Senha incorreta!", Toast.LENGTH_SHORT).show()
                        }
                        else -> {
                            userPrefs.saveLoggedUser(username)
                            Toast.makeText(context, "Login realizado com sucesso!", Toast.LENGTH_SHORT).show()
                            navController.navigate("finance")
                        }
                    }
                },
                modifier = Modifier.weight(1f)
            ) {
                Text("Login")
            }

            Button(
                onClick = {
                    navController.navigate("register")
                },
                modifier = Modifier.weight(1f)
            ) {
                Text("Cadastrar")
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        Button(
            onClick = { themeViewModel.toggleTheme() },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (isDarkTheme) "Alternar para Tema Claro" else "Alternar para Tema Escuro")
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 🔔 Botão para testar notificação manual
        Button(
            onClick = {
                val channelId = "monthly_reminder"
                val notificationId = 999
                val title = "🔔 Notificação de Teste"
                val message = "Esta é uma notificação enviada manualmente."

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val name = "FinanceReminderChannel"
                    val descriptionText = "Canal de lembrete mensal"
                    val importance = NotificationManager.IMPORTANCE_HIGH
                    val channel = NotificationChannel(channelId, name, importance).apply {
                        description = descriptionText
                    }
                    val notificationManager: NotificationManager =
                        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                    notificationManager.createNotificationChannel(channel)
                }

                val builder = NotificationCompat.Builder(context, channelId)
                    .setSmallIcon(android.R.drawable.ic_popup_reminder)
                    .setContentTitle(title)
                    .setContentText(message)
                    .setPriority(NotificationCompat.PRIORITY_HIGH) // ✅ aparece na tela
                    .setDefaults(NotificationCompat.DEFAULT_ALL)
                    .setAutoCancel(true)

                with(NotificationManagerCompat.from(context)) {
                    notify(notificationId, builder.build())
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("🔔 Testar Notificação (Manual)")
        }
    }
}

package com.example.myapplication.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.myapplication.FinancePreferences
import com.example.myapplication.UserPreferences

@Composable
fun EditarMesScreen(
    navController: NavController,
    mesAno: String
) {
    val context = LocalContext.current
    val financePrefs = remember { FinancePreferences(context) }
    val userPrefs = remember { UserPreferences(context) }

    val username = userPrefs.getLoggedUser()
    val dados = financePrefs.getFinanceData(username, mesAno)

    var salario by remember { mutableStateOf(dados["salary"] ?: "") }
    var gastosFixos by remember { mutableStateOf(dados["fixed"] ?: "") }
    var gastosSup by remember { mutableStateOf(dados["variable"] ?: "") }
    var gastosEmerg by remember { mutableStateOf(dados["emergency"] ?: "") }
    var meta by remember { mutableStateOf(dados["goal"] ?: "") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp)
    ) {
        Text("Editar Mês $mesAno", style = MaterialTheme.typography.headlineSmall)
        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = salario,
            onValueChange = { salario = it },
            label = { Text("Salário (R$)") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = gastosFixos,
            onValueChange = { gastosFixos = it },
            label = { Text("Gastos Fixos (R$)") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = gastosSup,
            onValueChange = { gastosSup = it },
            label = { Text("Gastos Supérfluos (R$)") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = gastosEmerg,
            onValueChange = { gastosEmerg = it },
            label = { Text("Gastos Emergenciais (R$)") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = meta,
            onValueChange = { meta = it },
            label = { Text("Meta de Economia (R$)") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = {
                financePrefs.saveFinanceData(
                    username,
                    mesAno,
                    salario,
                    gastosFixos,
                    gastosSup,
                    gastosEmerg,
                    meta
                )
                navController.navigate("resultado/$mesAno")
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Salvar Alterações")
        }

        Spacer(modifier = Modifier.height(12.dp))

        Button(
            onClick = { navController.popBackStack() },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Cancelar")
        }
    }
}
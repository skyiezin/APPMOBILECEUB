package com.example.myapplication.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.myapplication.ui.screens.*
import androidx.navigation.compose.rememberNavController
import com.example.myapplication.ThemeViewModel

@Composable
fun AppNavGraph(themeViewModel: ThemeViewModel) {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "login") {
        composable("login") {
            LoginScreen(navController, themeViewModel)
        }
        composable("register") {
            RegisterScreen(navController)
        }
        composable("finance") {
            FinanceDataScreen(navController)
        }
        composable("profile") {
            ProfileScreen(navController, themeViewModel)
        }
        composable("resultado/{mesAno}") { back ->
            val mesAno = back.arguments?.getString("mesAno") ?: ""
            ResultadoFinanceiroScreen(navController, mesAno)
        }
        composable("meses") {
            MesesAnterioresScreen(navController)
        }
        composable("editar/{mesAno}") { back ->
            val mesAno = back.arguments?.getString("mesAno") ?: ""
            EditarMesScreen(navController, mesAno)
        }
        composable("editar_perfil") {
            EditarPerfilScreen(navController)
        }
        composable("graficoGastos") {
            GraficoGastosScreen(navController)
        }
        composable("relatorioAnual") {
            RelatorioAnualScreen(navController)
        }
    }
}

package com.example.myapplication.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.myapplication.FinancePreferences
import com.example.myapplication.UserPreferences

@Composable
fun ResultadoFinanceiroScreen(navController: NavController, mesAno: String) {
    val context = LocalContext.current
    val userPrefs = UserPreferences(context)
    val financePrefs = FinancePreferences(context)

    val username = userPrefs.getLoggedUser()
    val dados = financePrefs.getFinanceData(username, mesAno)

    val salario = dados["salary"]?.toFloatOrNull() ?: 0f
    val gastosFixos = dados["fixed"]?.toFloatOrNull() ?: 0f
    val gastosSup = dados["variable"]?.toFloatOrNull() ?: 0f
    val gastosEmerg = dados["emergency"]?.toFloatOrNull() ?: 0f
    val meta = dados["goal"]?.toFloatOrNull() ?: 0f

    val totalGastos = gastosFixos + gastosSup + gastosEmerg
    val economia = salario - totalGastos
    val atingiuMeta = economia >= meta

    val maiorGasto = listOf(
        "Gastos Fixos" to gastosFixos,
        "Supérfluos" to gastosSup,
        "Emergenciais" to gastosEmerg
    ).maxByOrNull { it.second }

    var showDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("Resumo de $mesAno", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(16.dp))

        Text("Total de gastos: R$ %.2f".format(totalGastos))
        Text("Economia: R$ %.2f".format(economia))
        Text("Meta atingida: ${if (atingiuMeta) "Sim 🎉" else "Não ❌"}")
        Text("Maior tipo de gasto: ${maiorGasto?.first} (R$ %.2f)".format(maiorGasto?.second ?: 0f))

        Spacer(modifier = Modifier.height(32.dp))

        Button(onClick = { navController.navigate("finance") }, modifier = Modifier.fillMaxWidth()) {
            Text("Cadastrar novo mês")
        }

        Spacer(modifier = Modifier.height(8.dp))
        Button(onClick = { navController.navigate("meses") }, modifier = Modifier.fillMaxWidth()) {
            Text("Ver meses anteriores")
        }

        Spacer(modifier = Modifier.height(8.dp))
        Button(onClick = { navController.navigate("profile") }, modifier = Modifier.fillMaxWidth()) {
            Text("Voltar para o perfil")
        }

        Spacer(modifier = Modifier.height(8.dp))
        Button(onClick = { navController.navigate("editar/$mesAno") }, modifier = Modifier.fillMaxWidth()) {
            Text("Editar este mês")
        }

        Spacer(modifier = Modifier.height(8.dp))
        Button(
            onClick = { showDialog = true },
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Excluir este mês")
        }

        Spacer(modifier = Modifier.height(8.dp))
        Button(onClick = { navController.navigate("graficoGastos") }, modifier = Modifier.fillMaxWidth()) {
            Text("Ver gráfico de gastos")
        }
    }

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("Confirmar exclusão") },
            text = { Text("Tem certeza que deseja excluir os dados de $mesAno?") },
            confirmButton = {
                TextButton(onClick = {
                    financePrefs.deleteFinanceData(username, mesAno)
                    Toast.makeText(context, "Mês $mesAno excluído!", Toast.LENGTH_SHORT).show()
                    showDialog = false
                    navController.navigate("meses")
                }) {
                    Text("Excluir")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDialog = false }) {
                    Text("Cancelar")
                }
            }
        )
    }
}
